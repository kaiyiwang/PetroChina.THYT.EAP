//
//  ZongHeBG_XiaoShDT.swift
//  PetroChina.THYT.ZongHBG
//
//  Created by Mensp on 14/10/30.
//  Copyright (c) 2014年 PetroChina. All rights reserved.
//

import UIKit

class ZongHeBG_XiaoShDT: UITableViewController {


    @IBOutlet weak var wvXiaoShDT: UIWebView!
  override func viewDidLoad() {
       super.viewDidLoad()
        
        // Do any additional setup after loading the view.
       var url:NSURL = NSURL(string:"http://10.218.8.35:8080/DayReport/cyc_rb/xsdt/xsdtsy.jsp")!
        var request:NSURLRequest = NSURLRequest(URL:url)
        self.wvXiaoShDT.loadRequest(request)
    }
    
   override func didReceiveMemoryWarning() {
       super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    /*
    // MARK: - Navigation
    
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    // Get the new view controller using segue.destinationViewController.
    // Pass the selected object to the new view controller.
    }
    */

}
