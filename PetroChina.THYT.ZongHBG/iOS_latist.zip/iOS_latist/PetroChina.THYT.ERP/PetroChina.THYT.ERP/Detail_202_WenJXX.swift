//
//  Detail_202_WenJXX.swift
//  PetroChina.THYT.ERP
//
//  Created by zhaitingting on 14/10/31.
//  Copyright (c) 2014年 PetroChina. All rights reserved.
//

import UIKit

class Detail_202_WenJXX: NSObject {
    //文件信息 列表
    var adjunctId:NSString = ""// 文件信息编号
    var adjunctTitle:NSString = ""// 文件信息标题
    var adjunctPath:NSString = ""// 文件路径
}
