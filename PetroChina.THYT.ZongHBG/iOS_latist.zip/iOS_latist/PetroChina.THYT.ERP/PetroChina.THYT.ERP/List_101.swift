//
//  List_101.swift
//  PetroChina.THYT.ERP
//
//  Created by Mensp on 14/10/24.
//  Copyright (c) 2014年 PetroChina. All rights reserved.
//

import UIKit

class List_101: NSObject {
   
    var approveId:NSString = ""//待办审批业务编号
    var personTaskId:NSString = ""//个人待办工作编号
    var businessId:NSString = ""//数据主键编号
    var moduleId:NSString = ""//模块编号
    var collectNum:NSString = ""//计划汇总编号
    var collectUnitName:NSString = ""//汇总单位
    var collectDepartName:NSString = ""//汇总部门
    var collectPerson:NSString = ""//计划汇总人
    var collectDate:NSString = ""//汇总时间
    var collectComment:NSString = ""//汇总意见
}
