//
//  Detail_312_ShenPZhT.swift
//  PetroChina.THYT.ERP
//
//  Created by Mensp on 14/10/24.
//  Copyright (c) 2014年 PetroChina. All rights reserved.
//

import UIKit

class Detail_312_ShenPZhT: NSObject {
   
    var moduleName:NSString = ""//项目编号
    var approvePerson:NSString = ""//项目编号
    var sendDate:NSString = ""//项目编号
    var approveDate:NSString = ""//项目编号
    var approveStateName:NSString = ""//项目编号
    var approve_comment:NSString = ""//项目编号
    var approveUnitName:NSString = ""//项目编号
    var approveDegree:NSString = ""//项目编号
}
