//
//  DataClass202.swift
//  PortTest
//
//  Created by zhaitingting on 14-10-16.
//  Copyright (c) 2014年 zhaitingting. All rights reserved.
//

import UIKit

class Detail_202: NSObject {
   
    var ctrName:NSString = ""//合同名称
    var ctrTypeName:NSString = ""//合同类型
    var reportNo:NSString = ""//报审序号
    var inputPersonDept:NSString = ""//承办人/单位
    var fundAllocation:NSString = ""//资金流向
    var fundDitchName:NSString = ""//资金渠道
    var inviteBidTypeName:NSString = ""//招标方式
    var budgetSum:NSString = ""//预算金额
    var priceTypeName:NSString = ""//货币类型
    var inviteBidKind:NSString = ""//招标组织形式
    var divideBid:NSString = ""//是否划分标段
    var inviteBidDesc:NSString = ""//招标方式说明
    var userContact:NSString = ""//用户联系人
    var userContactTel:NSString = ""//用户联系电话
    var performSpace:NSString = ""//履行地点
    var performStandard:NSString = ""//执行标准
    var qualityReq:NSString = ""//质量要求
    var valuationBasis:NSString = ""//计价依据
    var suppQualReq:NSString = ""//供应商资质要求
    var timeLimitDesc:NSString = ""//工期描述
    var projectDesc:NSString = ""//项目描述
    var remark:NSString = ""//备注
  
    
    
//    var errCode:NSString = ""
//    var errMsg:NSString = ""
    
}
