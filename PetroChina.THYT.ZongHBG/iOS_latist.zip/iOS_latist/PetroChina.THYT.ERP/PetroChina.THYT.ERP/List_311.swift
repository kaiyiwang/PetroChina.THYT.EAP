//
//  List_311.swift
//  PetroChina.THYT.ERP
//
//  Created by Mensp on 14/10/24.
//  Copyright (c) 2014年 PetroChina. All rights reserved.
//

import UIKit

class List_311: NSObject {
   
    var projectNum:NSString = ""//项目编号
    var projectName:NSString = ""//项目名称
    var bidTypeName:NSString = ""//招标类型名称
    var stockMethodName:NSString = ""//采购方式名称
    var currencyTypeName:NSString = ""//币种名称
    var applyUnitName:NSString = ""//申请单位名称
    var useUnitName:NSString = ""//用户单位名称
    var personTaskId:NSString = ""//待办编号
    var approveId:NSString = ""//审批编号
    var resultId:NSString = ""//结果编号
    var projectId:NSString = ""//结果编号
    
}
