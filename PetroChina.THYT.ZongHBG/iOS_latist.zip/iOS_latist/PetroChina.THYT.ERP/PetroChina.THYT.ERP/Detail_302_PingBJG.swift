//
//  Detail_302_PingBJGXX.swift
//  PetroChina.THYT.ERP
//
//  Created by Mensp on 14/10/24.
//  Copyright (c) 2014年 PetroChina. All rights reserved.
//

import UIKit

class Detail_302_PingBJG: NSObject {
   
    var providerName:NSString = "" //投标结果
    var sumQuoteMoney:NSString = "" //投标报价
    var deliveryDateText:NSString = "" //交货期（天）
    var jsScore:NSString = "" //技术
    var swScore:NSString = "" //商务
    var sumScore:NSString = "" //总分
    var Ranking:NSString = "" //名次
    var bidPhasePtNum:NSString = "" //标段编号
    var resultMoney:NSString = "" //采购结果总价
    var isConfirm:NSString = "" //是否中标
}
