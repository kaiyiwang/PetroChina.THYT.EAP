//
//  DataClass602WuCQShWZXX.swift
//  PortTest
//  物采缺少物资信息  true
//  平台缺少物资信息    false
//  Created by zhaitingting on 14/10/22.
//  Copyright (c) 2014年 zhaitingting. All rights reserved.
//

import UIKit

class Detail_602_WuCQShWZXX: NSObject {
    
    var matGroupId:String = ""//品名编码
    var matGroupName:String = ""//品名
    var matLevel:String = ""//物资级别
    var isWuZQShXX:Bool = true //
}
