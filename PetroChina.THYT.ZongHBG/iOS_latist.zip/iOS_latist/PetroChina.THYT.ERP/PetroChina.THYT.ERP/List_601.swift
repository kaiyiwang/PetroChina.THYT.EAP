//
//  DataClass601.swift
//  PortTest
//
//  Created by zhaitingting on 14-10-21.
//  Copyright (c) 2014年 zhaitingting. All rights reserved.
//

import UIKit

class List_601: NSObject {
    //数据属性
    var approveId:String = ""//待办审批业务编号
    var personTaskId:String = ""//个人待办工作编号
    var providerDetailId:String = ""//供应商详情编号
    var admitId:String = ""//准入序号
    var isHse:String = ""//是否选中HSE
    var businessId:String = ""//业务主键
    var tempProviderId:String = ""//供应商序号
    var providerName:String = ""//供应商名称
    var organizeNum:String = ""//组织机构代码
    var providerTypeName:String = ""//供应商类型
    var statusType:String = ""//业务类型
    var providerKindName:String = ""//相对人性质
    var juridicalPerson:String = ""//法定代表人
    var createDate:String = ""//申请准入时间
    var isReturn:String = ""//是否被退回
    
}
