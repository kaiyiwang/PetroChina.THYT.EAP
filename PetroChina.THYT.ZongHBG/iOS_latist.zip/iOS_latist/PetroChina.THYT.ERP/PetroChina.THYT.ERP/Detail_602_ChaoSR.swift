//
//  DataClass602ChaoSR.swift
//  PortTest
//  602抄送人列表 admitDetail
//  Created by zhaitingting on 14-10-21.
//  Copyright (c) 2014年 zhaitingting. All rights reserved.
//

import UIKit

class Detail_602_ChaoSR: NSObject {
    var approveUserId:String = ""//审批用户编号
    var approvePerson:String = ""//审批人
    var approveUnitId:String = ""//审批人单位编号
    var approveUnitName:String = ""//审批人单位名称
    var tablename:String = ""//业务表名
    var moduleName:String = ""//审批模块
}
