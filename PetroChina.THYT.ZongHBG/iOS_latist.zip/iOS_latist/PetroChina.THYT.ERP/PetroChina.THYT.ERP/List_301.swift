//
//  List_301.swift
//  PetroChina.THYT.ERP
//
//  Created by Mensp on 14/10/24.
//  Copyright (c) 2014年 PetroChina. All rights reserved.
//

import UIKit

class List_301: NSObject {
    
    var projectNum:String = "" //项目编号
    var projectName:String = ""//项目名称
    var wcWorkNum:String = ""//采购方案编号
    var stockMethodName:String = ""//采购方式名称
    var currencyTypeName:String = ""//币种名称
    var creatPerson:String = ""//业务员
    var openBidDate:String = ""//招标时间
    var personTaskId:String = ""//个人待办工作编号
    var approvedId:String = ""//待办审批业务编号
    var sourceId:String = ""//结果编号
    var projectPtId:String = ""//项目编号
}
