//
//  Detail_312_ZhaoBXX.swift
//  PetroChina.THYT.ERP
//
//  Created by Mensp on 14/10/24.
//  Copyright (c) 2014年 PetroChina. All rights reserved.
//

import UIKit

class Detail_312_ZhaoBXX: NSObject {
    
    var providerName:NSString = ""//项目编号
    var resultMoney:NSString = ""//项目编号
    var deliveryDate:NSString = ""//项目编号
    var linkPerson:NSString = ""//项目编号
    var linkPhone:NSString = ""//项目编号
    var myNum:NSString = ""//项目编号
    var isConfirm:NSString = ""//项目编号
   
    
}
