//
//  Detail_202_NiXDW.swift
//  PetroChina.THYT.ERP
//
//  Created by zhaitingting on 14/10/31.
//  Copyright (c) 2014年 PetroChina. All rights reserved.
//

import UIKit

class Detail_202_NiXDW: NSObject {
    //拟选投标单位、列表
    //    var providerId:NSArray = []//单位编号
    //    var Provider:NSArray = []//单位名称
    var providerId:NSString = ""//单位编号
    var Provider:NSString = ""//单位名称
}
