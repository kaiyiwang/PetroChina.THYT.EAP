//
//  Detail_302_ShenPDT.swift
//  PetroChina.THYT.ERP
//
//  Created by Mensp on 14/10/24.
//  Copyright (c) 2014年 PetroChina. All rights reserved.
//

import UIKit

class Detail_302_ShenPZhT: NSObject {
   
    var moduleName:NSString = ""//审批模块
    var approvePerson:NSString = "" //审批人
    var sendDate:NSString = "" //送审时间
    var approveDate:NSString = "" //审批时间
    var approveStateName:NSString = "" //审批状态
    var approveComment:NSString = "" //审批意见
    var approveUnitName:NSString = "" //审批人单位名称
    var approveDegree:NSString = "" //审批顺序
    
}
