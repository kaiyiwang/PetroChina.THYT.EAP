//
//  Detail_102.swift
//  PetroChina.THYT.ERP
//
//  Created by Mensp on 14/10/24.
//  Copyright (c) 2014年 PetroChina. All rights reserved.
//

import UIKit

class Detail_102: NSObject {
   
//    var approveId:NSString = ""//待办审批业务编号
//    var personTaskId:NSString = ""//个人待办工作编号
//    var businessId:NSString = ""//数据主键编号
//    var moduleId:NSString = ""//模块编号
    var collectNum:NSString = ""//汇总编号
    var plan2ndNum:NSString = ""//编制编号
    var matGroupId:NSString = ""//物料组
    var matId:NSString = ""//物料号
    var matName:NSString = ""//物料名称
    var matUnit:NSString = ""//计量单位
    var reqAmount:NSString = ""//需求数量
    var matPrice:NSString = ""//预计单价
    var preAmount:NSString = ""//预计采购数量
    var technicReq:NSString = ""//技术要求
    var plan2ndMxId:NSString = ""//物资主键编号
    
   

}
