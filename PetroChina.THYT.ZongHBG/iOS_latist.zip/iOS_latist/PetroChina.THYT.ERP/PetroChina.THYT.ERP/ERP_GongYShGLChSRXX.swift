//
//  ERP_GongYShGLChSRXX.swift
//  PetroChina.THYT.ERP
//
//  Created by zhaitingting on 14/10/25.
//  Copyright (c) 2014年 PetroChina. All rights reserved.
//

import UIKit

class ERP_GongYShGLChSRXX: UITableViewController {


    var finalData:Array<Detail_602_ChaoSR> = [] // 抄送人
    var dataBase:Detail_602_Base! //基本信息
    var dataFuJXX:Array<Detail_602_FuJXX> = [] //附件信息
    var currentDataFuJXX:Detail_602_FuJXX!
    
    var dataFuJBase:Array<Detail_602_FuJXX> = [] //附件基本信息
//    var currentDataFuJBase:Detail_602_FuJXX!
    var dataFuJKuoZh:Array<Detail_602_FuJXX> = [] // 附件扩展信息
//    var currentDataFuJKuoZh:Detail_602_FuJXX!
    var dataFuJShenH:Array<Detail_602_FuJXX> = [] //附件审核信息
//    var currentDataFuJShenH:Detail_602_FuJXX!
    @IBOutlet weak var showChaoSR: UILabel!
    //接收列表界面的ID
    var approId:NSString = ""
    var perTaskId:NSString = ""
    var providerDetailId:NSString = ""
    var admitId:NSString = ""// 准入序号
    var isHse:NSString = ""
    var statusType:NSString = ""
    var businessId:NSString = ""
    var appUserId:NSString = ""
    
    //要发送给服务器字符串
    var unitId:NSString = "" //审核人单位
    var appScope:NSString = "" // 审批准入范围
    var email:NSString = "" //邮箱
    var tempProId:NSString = "" // 供应商编号
    var tempProDetailId:NSString = "" //供应商详情编号
    var proName:NSString = "" //供应商名称
    
    //业务类型变更的radioBtn的状态
    var stateLeft = 0
    var stateRight = 0
    
    
    
    
    
    var url:NSString = "http://10.218.8.213:8620/thwlpt/ws/MOVE602"
    var soapStr:NSMutableString = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:sap=\"http://sap.move.com/\"><soapenv:Header/><soapenv:Body><sap:ResultDetailsQuery><!--Optional:--><arg0>&lt;?xml version='1.0' encoding='utf-8'?&gt;&lt;xuanShang&gt;&lt;row&gt;&lt;approveId&gt;"
    
    let TAG_CELL_LABELLeft = 1
    let TAG_CELL_LABELRight = 2
    
    var b = ERP_GongYShGL_Detail_602()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        var data:NSData!
        var sp = NSSearchPathForDirectoriesInDomains(NSSearchPathDirectory.DocumentDirectory, NSSearchPathDomainMask.AllDomainsMask, true) //获取目录
        
        if sp.count > 0{
            var urlText = NSURL(fileURLWithPath: "\(sp[0])/data601.txt")
            if let b = urlText?.path{
                data = NSData(contentsOfFile: b)
            }
            var strId:NSString = NSString(data: data, encoding: NSUTF8StringEncoding)!//获取到aproId
            var strArray:NSArray = strId.componentsSeparatedByString(",")
            //            for str in strArray {
            //                println(str)
            //            }
            //            self.tbview.addSubview(myView)
            approId = strArray[0] as NSString
            perTaskId = strArray[1] as NSString
            providerDetailId = strArray[2] as NSString
            admitId = strArray[3] as NSString
            isHse = strArray[4] as NSString
            statusType = strArray[5] as NSString
            businessId = strArray[6] as NSString
            appUserId = strArray[7] as NSString
            soapStr.appendString(appUserId)
            soapStr.appendString("&lt;/approveId&gt; &lt;personTaskId&gt;")
            soapStr.appendString(perTaskId)
            soapStr.appendString("&lt;/personTaskId&gt;&lt;providerDetailId&gt;")
            soapStr.appendString(providerDetailId)
            soapStr.appendString("&lt;/providerDetailId&gt;&lt;admitId&gt;")
            soapStr.appendString(admitId)
            soapStr.appendString("&lt;/admitId&gt;&lt;isHse&gt;")
            soapStr.appendString(isHse)
            soapStr.appendString("&lt;/isHse&gt;&lt;statusType&gt;")
            soapStr.appendString(statusType)
            soapStr.appendString("&lt;/statusType&gt;&lt;businessId&gt;")
            soapStr.appendString(businessId)
            soapStr.appendString("&lt;/businessId&gt;&lt;appUserId&gt;")
            soapStr.appendString(appUserId)
            soapStr.appendString("&lt;/appUserId&gt;&lt;/row&gt; &lt;/xuanShang&gt;</arg0></sap:ResultDetailsQuery></soapenv:Body></soapenv:Envelope>")
            b.connectToUrl(url, soapStr: soapStr)
            finalData = b.parserDataChaoSR
            dataBase = b.parserDataBase
            dataFuJXX = b.parserDataFuJXX
            distinguishDataOfFujian(dataFuJXX)
            var bbbb = finalData[0]
            showChaoSR.text = bbbb.approvePerson
            
            
        }
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }
    //讲信息区分，1.附件信息2.扩展附件信息3.审核附件信息
    func distinguishDataOfFujian(dataArray:Array<Detail_602_FuJXX>){
        for obj in dataArray {
            if obj.isExtecsion == 0 {
//                println(0) 
                dataFuJBase.append(obj)
                
            }
            if obj.isExtecsion == 1 {
//                println(1)
                dataFuJKuoZh.append(obj)
            }
            if obj.isExtecsion == 2 {
//                println(2)
                dataFuJShenH.append(obj)
            }
        }
        println("\(dataFuJBase.count)")
    }
    //radio控件
    
    @IBOutlet weak var radioBianG_R: UIButton!
    @IBOutlet weak var radioBianG_L: UIButton!
    @IBAction func radioBtn_BianG_LeftClicked(sender: AnyObject) {
        if stateRight == 1 || stateLeft == 0{
            if stateLeft == 0 {
                var image = UIImage(named: "radio_on")
                radioBianG_L.setBackgroundImage(image, forState: nil)
                var imageOff = UIImage(named: "radio_off")
                radioBianG_R.setBackgroundImage(imageOff, forState: nil)
                stateLeft = 1
                stateRight = 0
            }
        }
     
        
    }
    @IBAction func radioBtn_BianG_RightClicked(sender: AnyObject) {
        if stateLeft == 1 || stateRight == 0{
            if stateRight == 0 {
                var image = UIImage(named: "radio_on")
                radioBianG_R.setBackgroundImage(image, forState: nil)
                var imageOff = UIImage(named: "radio_off")
                radioBianG_L.setBackgroundImage(imageOff, forState: nil)
                stateRight = 1
                stateLeft = 0
            }

        }
            }
    //安全环保审批radio
    var st1L = 0
    var st1R = 0
    @IBOutlet weak var HuanBaoRight: UIButton!
    @IBOutlet weak var HuanBaoLeft: UIButton!
    @IBAction func radioHuanBLeft(sender: AnyObject) {
        if st1R == 1 || st1L == 0{
            if st1L == 0 {
                var image = UIImage(named: "radio_on")
                HuanBaoLeft.setBackgroundImage(image, forState: nil)
                var imageOff = UIImage(named: "radio_off")
                HuanBaoRight.setBackgroundImage(imageOff, forState: nil)
                st1L = 1
                st1R = 0
            }
        }

    }
    @IBAction func radioHuanBRight(sender: AnyObject) {
        if st1L == 1 || st1R == 0{
            if st1R == 0 {
                var image = UIImage(named: "radio_on")
                HuanBaoRight.setBackgroundImage(image, forState: nil)
                var imageOff = UIImage(named: "radio_off")
                HuanBaoLeft.setBackgroundImage(imageOff, forState: nil)
                st1R = 1
                st1L = 0
            }
        }

    }
    //物资审批radio
    var st2L = 0
    var st2R = 0
    @IBOutlet weak var ShenPLeft: UIButton!
    @IBOutlet weak var ShenPRight: UIButton!
    @IBAction func radioShenPLeft(sender: AnyObject) {
        if st2R == 1 || st2L == 0{
            if st2L == 0 {
                var image = UIImage(named: "radio_on")
                ShenPLeft.setBackgroundImage(image, forState: nil)
                var imageOff = UIImage(named: "radio_off")
                ShenPRight.setBackgroundImage(imageOff, forState: nil)
                st2L = 1
                st2R = 0
            }
        }

    }
    @IBAction func radioShenPRight(sender: AnyObject) {
        if st2L == 1 || st2R == 0{
            if st2R == 0 {
                var image = UIImage(named: "radio_on")
                ShenPRight.setBackgroundImage(image, forState: nil)
                var imageOff = UIImage(named: "radio_off")
                ShenPLeft.setBackgroundImage(imageOff, forState: nil)
                st2R = 1
                st2L = 0
            }
        }
    }
    //审批结果radio
    var st3L = 0
    var st3R = 0
    @IBOutlet weak var JieGRight: UIButton!
    @IBOutlet weak var JieGLeft: UIButton!
    @IBAction func radioJieGRight(sender: AnyObject) {
        if st3L == 1 || st3R == 0{
            if st3R == 0 {
                var image = UIImage(named: "radio_on")
                JieGRight.setBackgroundImage(image, forState: nil)
                var imageOff = UIImage(named: "radio_off")
                JieGLeft.setBackgroundImage(imageOff, forState: nil)
                st3L = 0
                st3R = 1
            }
        }

    }
    
    @IBAction func radioJieGLeft(sender: AnyObject) {
        if st3R == 1 || st3L == 0{
            if st3L == 0 {
                var image = UIImage(named: "radio_on")
                JieGLeft.setBackgroundImage(image, forState: nil)
                var imageOff = UIImage(named: "radio_off")
                JieGRight.setBackgroundImage(imageOff, forState: nil)
                st3R = 0
                st3L = 1
            }
        }
    }
    
    @IBOutlet weak var remarkXX: UITextField!  //物资备注
    @IBOutlet weak var approveCommentXX: UITextField! //审批意见
    @IBOutlet weak var wzRemarkXX: UITextField! //备注信息
    //checkBox 控件
    @IBOutlet weak var check: UIButton!
    var isCheck = 0
    @IBAction func btn_Checked(sender: AnyObject) {
        if isCheck == 0 {
           
            var checkImage = UIImage(named: "check_on")
            check.setBackgroundImage(checkImage, forState: nil)
            isCheck = 1
        }else if isCheck == 1 {
            var checkImage = UIImage(named: "check_off")
            check.setBackgroundImage(checkImage, forState: nil)
            isCheck = 0
        }
    }
    
    @IBOutlet weak var btn_QueD: UIButton!
    var status:NSInteger = 0 //当前的状态 0表示临时保存 1表示提交
    @IBAction func btn_QueDing(sender: AnyObject) {
        status = 1
        //获取数据
        updateAllSendData()
        //发送数据
        
    }
    @IBAction func btn_LinShBaoCun(sender: AnyObject) {
        status = 0
        //获取数据
        updateAllSendData()
        //发送数据
        
    }
    //定义 = 0要发送的数据
    var changeTypeState:NSInteger = 0 //业务类型是否变更
    var isHseState:NSInteger = 0 //安全环保处审批
    var productPassedState:NSInteger = 0 //物资审批
    var passedState:NSInteger = 0 //审批结果
    func updateAllSendData(){
        if stateLeft == 1 {
            changeTypeState = 0
        }else if stateRight == 1 {
            changeTypeState = 1
        }
        if st1L == 1 {
            isHseState = 0
        }else if st1R == 1 {
            isHseState = 1
        }
        if st2L == 1 {
            productPassedState = 0
        }else if st2R == 1 {
            productPassedState = 1
        }
        if st3L == 1{
            passedState = 0
        }else if st3R == 1 {
            passedState = 1
        }
        
        //判断是否有抄送人信息
        var hasChaoSR = 0  //有没有抄送人信息
        if finalData.count == 1 && finalData[0].approvePerson == "" {
            hasChaoSR = 0
        }else{
            hasChaoSR = finalData.count
        }
//        println("抄送人：\(hasChaoSR)")
//        println("\(changeTypeState)  \(isHseState)  \(productPassedState) \(passedState)")
        
//        println("stateLeft:\(stateLeft) stateRight:\(stateRight)")
//        println("stateLeft1:\(st1L) stateRight:\(st1R)")
//        println("stateLeft2:\(st2L) stateRight:\(st2R)")
//        println("stateLeft3:\(st3L) stateRight:\(st3R)")
//        println("check:\(isCheck)")
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
  
    
}
