//
//  Detail_202_ChaoSYHXX.swift
//  PetroChina.THYT.ERP
//
//  Created by zhaitingting on 14/10/31.
//  Copyright (c) 2014年 PetroChina. All rights reserved.
//

import UIKit

class Detail_202_ChaoSYHXX: NSObject {
    //抄送用户信息 列表
    var approveUserId:NSString = ""// 抄送人编号
    var approvePerson:NSString = ""// 抄送人
    var approveUnit:NSString = ""// 单位名称
}
